# Projet POO - Donjon-RPG

* Concevoir et developper un projet complet selon la logique orientee-objet
* Savoir utiliser les diagrammes utiles pour concevoir et documenter le projet
* Comprendre les relations entre COO et POO

## Etudiants

* Lenny Louis
* [Morgan Nehdi](https://morgan-nehdi.com/)


![logo](https://upload.wikimedia.org/wikipedia/commons/f/f8/LOGO-ORIGINAL_WEB.jpg "Logo IUT Laval")