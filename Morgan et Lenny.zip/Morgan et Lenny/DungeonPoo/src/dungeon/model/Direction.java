package dungeon.model;

import java.io.Serializable;

public enum Direction implements Serializable {
    NONE, WEST, EAST, NORTH, SOUTH;
}
